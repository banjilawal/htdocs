<?php
    require_once(../model/c)
?>