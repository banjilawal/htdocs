<?php
    require_once ('../model/customer.php');

    print_r($_POST);
    $firstName = $_POST["firstname"];
    $email = $_POST["email"];
    echo '<p></p>' . $firstName . ' ' . $email . '<p></p>';

    $server = "localhost";
    $user = "root";
    $pass = "";
    $database = "mysql";

    $conn = new mysqli($server, $user, $pass, $database);


    $stmt = "CREATE USER ' colburn.vickers'@'shaw.ca'";
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully" . '<p></p>';

    $result = $conn->query($stmt);
    $conn->query("FLUSH PRIVILEGES;");
?>