<?php
    require_once ('../model/customer.php');

    print_r($_POST);
    $first
?>