<?php
    require_once ('../model/customer.php');

    
?>