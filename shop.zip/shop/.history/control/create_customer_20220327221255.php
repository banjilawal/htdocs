<?php
    require_once (../model)
?>