<?php
    require_once(../mo)
?>