<?php
    require_once (../modelcustomer.php);
?>