<?php
    require_once ('../model/customer.php');

    print_r($_POST);
    $firstName = $_POST["firstname"];
    $email = $_["email"];
    echo '<p></p>' . $firstName . '' '<p></p>';
?>