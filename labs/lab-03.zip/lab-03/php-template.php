<!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--<script type="text/javascript" src="script.js"></script> --> 
        
        <title>The Template Title</title>
    </head>

<!--######## Begin Body ########-->
    <body>   
        <!--######## Start Header Section ########-->
        <header>

        </header>
        <!--######## End Header Section ########-->

        <!--######## Start Nav Section ########-->
        <nav>

        </nav>
        <!--######## End Nav Section ########-->

        <!--######## Start Main Section ########-->
        <main>

        </main>
        <!--######## End Main Section ########--> 
        <form id="shoe-order-form" name="shoe-order-form" method="post" action="shoe-order-form-processor.php">

        </form>

        <!--######## Start Footer Section ########-->   
        <footer>

        </footer>
        <!--######## End Footer Section ########-->
    </body>
<!--######## Finish Body ########-->
<html>